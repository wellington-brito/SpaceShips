package com.swapi;

/**
 * Created by Oleur on 21/12/2014.
 * API constants
 */
public class APIConstants {
    public static final String BASE_URL = "http://swapi.co/api";
}
